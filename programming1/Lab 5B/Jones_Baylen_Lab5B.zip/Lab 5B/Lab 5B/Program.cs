﻿using System;
using Tester;

namespace Lab_5B
{
    class Program
    {
        static void Main(string[] args)
        {
            Test.Run(5);
            Console.ReadKey();
        }
    }
}
