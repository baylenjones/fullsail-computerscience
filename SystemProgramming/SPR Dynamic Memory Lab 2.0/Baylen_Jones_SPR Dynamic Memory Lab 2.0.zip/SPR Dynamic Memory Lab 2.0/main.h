#pragma once

void ScopeMain();